import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// Modules
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { FilterPipe } from './pipes/filter.pipe';
// Components
import { AppComponent } from './components/index/app.component';
import { AppRoutingModule } from './app-routing.module';
import { ProductAddComponent } from './components/Product Management/product-add/product-add.component';
import { ProductListComponent } from './components/Product Management/product-list/product-list.component';
import { ProductService } from './services/product/product.service';
import { HomeComponent } from './components/home/home.component';
import { CartProductListComponent } from './components/Product Management/cart-product-list/cart-product-list.component';
import { CartListComponent } from './components/Product Management/cart-list/cart-list.component';





@NgModule({
	declarations: [
		AppComponent,
		HomeComponent,
		ProductAddComponent,
		ProductListComponent,
		FilterPipe,
		CartProductListComponent,
		CartListComponent		

	],
	imports: [
		BrowserModule,
		RouterModule,
		AppRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		BrowserAnimationsModule,
		HttpClientModule,
		ToastrModule.forRoot({
			timeOut: 3000,
			positionClass: 'toast-bottom-right',
			preventDuplicates: true,
		}),
	],
	providers: [ProductService],
	bootstrap: [AppComponent]
})

// enableProdMode();

export class AppModule { }
