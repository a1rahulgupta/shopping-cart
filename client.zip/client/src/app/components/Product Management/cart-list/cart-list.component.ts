import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.scss']
})
export class CartListComponent implements OnInit {

  public totalCount: number = 0;
  public pagination: any = {
    'page': 1,
    'pagesize': 5
  };
  allProductList: any = [];
  public imageUrl = 'http://localhost:5005/public/';
  constructor(private productService: ProductService, private toastr: ToastrService,private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.getAllProduct();
  }

  public getAllProduct() {
    this.productService.getAllProduct(this.pagination).subscribe((result) => {
      if (result.status === 1) {
        this.totalCount = Math.ceil(parseInt(result.data.total_count) / this.pagination.count);
        this.allProductList = result.data.listing;
      } else {
        this.toastr.error(result.message);
      }
    });
  }

  addProductToCart(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.addProductToCart({ productId: productId }).subscribe((result) => {
        const rs = result;
        console.log(rs)
        if (rs.status === 1) {
          this.toastr.success('Success', rs.message);
          this.router.navigate(['/list/cart-product-list']);
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }
}