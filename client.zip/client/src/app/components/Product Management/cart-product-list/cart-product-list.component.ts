import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-cart-product-list',
  templateUrl: './cart-product-list.component.html',
  styleUrls: ['./cart-product-list.component.scss']
})
export class CartProductListComponent implements OnInit {
  public totalCount: number = 0;
  public pagination: any = {
    'page': 1,
    'pagesize': 5
  };
  allProductList: any = [];
  public imageUrl = 'http://localhost:5005/public/';

  total: number = 0;

  constructor(private productService: ProductService, private toastr: ToastrService) { }

  ngOnInit() {
    this.gatCartList();

  }

  totalPrice() {
    console.log(this.allProductList);
    this.total = 0;
    for (var i = 0; i < this.allProductList.length; i++) {
      this.total += (this.allProductList[i].productId.price * this.allProductList[i].productId.quantity);
    }
  }

  add(pid) {
    for (var i = 0; i < this.allProductList.length; i++) {
      if (this.allProductList[i].productId._id === pid) {
        this.allProductList[i].productId.quantity += 1;

      }
    }
    this.totalPrice();
  }

  del(pid) {
    for (var i = 0; i < this.allProductList.length; i++) {
      if (this.allProductList[i].productId._id === pid) {
        this.allProductList[i].productId.quantity -= 1;

      }
      if (this.allProductList[i].productId.quantity > 1) {
        this.totalPrice();
      } else {
        this.allProductList[i].productId.quantity = 1;
      }
    }


  }

  public gatCartList() {
    this.productService.gatCartList(this.pagination).subscribe((result) => {
      if (result.status === 1) {
        this.totalCount = Math.ceil(parseInt(result.data.total_count) / this.pagination.count);
        this.allProductList = result.data.listing;
        this.totalPrice();
      } else {
        this.toastr.error(result.message);
      }
    });
  }

  deleteProductInCart(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.deleteProductInCart({ productId: productId }).subscribe((result) => {
        const rs = result;
        if (rs.status === 1) {
          this.toastr.success('Success', rs.message);
          this.gatCartList();
          this.totalPrice();
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }

}