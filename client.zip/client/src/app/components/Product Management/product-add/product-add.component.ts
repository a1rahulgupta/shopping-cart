import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import {  Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../../services/product/product.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.scss']
})
export class ProductAddComponent implements OnInit {
  productAddForm: FormGroup;
  productId: any;
  prdctData: any = {};
  categoryData: any = [];
  public imageUrl = 'http://localhost:5005/public/';
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private productService: ProductService, private toastr: ToastrService) {
    this.route.params.subscribe(params => {
			this.productId = params['id'];
			// check if ID exists in route & call update or add methods accordingly
			if (this.productId && this.productId !== null && this.productId !== undefined) {
				this.getProductDetails(this.productId);
			} else {
				this.createForm(null);
			}
		});
  }
  ngOnInit() {
  }

  doRegister() {
		if (this.productId && this.productId !== null && this.productId !== undefined) {
      this.productAddForm.value.id = this.productId;
      this.updateProduct();
		} else {
      this.productId = null;
      this.addNewProduct();
    }
}

addNewProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  this.productService.addNewProduct(this.productAddForm.value).subscribe((res: any) => {
    console.log(res)	
    if (res.status === 1) {
      this.toastr.success(res.message, 'Success');
      this.router.navigate(['/list']);
    } else {
      this.toastr.error(res.message, 'Failed');
    }
})
}
updateProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  this.productService.updateProduct(this.productAddForm.value).subscribe((result) => {
    const rs = result;
    if (rs.status === 1) {
      this.router.navigate(['/list']);
      this.toastr.success("success",rs.message);
    } else {
      this.toastr.error(rs.message);
    }
  });
}
  getProductDetails(ProductId){
    console.log(ProductId)
    this.productService.getProductById(ProductId).subscribe((result) => {
      const rs = result;
      if (rs.status === 1) {
        this.createForm(rs.data);
      } else {
        this.toastr.error(rs.message);
      }
    });
  }



  createForm(data) {
    if (data === null) {
      this.productAddForm = this.formBuilder.group({
        itemName: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        price: ['', [Validators.required,
          Validators.pattern("^[0-9]*$"),
          Validators.minLength(2),Validators.maxLength(5)]],
        image:['']
      });
    } else {
      
      this.prdctData.productImage = data.image
      this.productAddForm = this.formBuilder.group({
        itemName: [data.itemName, [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        price: [data.price, [Validators.required,
          Validators.pattern("^[0-9]*$"),
          Validators.minLength(2),Validators.maxLength(5)]]
      });
    }
  }

  fileChange(e, type?) {
    let form = new FormData();
    form.append('file', e.target.files[0]);
    this.fileUpload(form, type);
  }

  fileUpload(image, type) {
      this.productService.fileUpload(image).subscribe((result) => {
      if (result.status == 1) {
        this.prdctData.productImage = result.fileName 
      }
    });
  }

}

