import { Component, OnInit, Inject } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  public totalCount: number = 0;
  public pagination: any = {
    'page': 1,
    'pagesize': 5
  };
  allProductList: any = [];
  public imageUrl = 'http://localhost:5005/public/';
  constructor(private productService: ProductService, private toastr: ToastrService) { }

  ngOnInit() {
    this.getAllProduct();
  }

  public getAllProduct() {
    this.productService.getAllProduct(this.pagination).subscribe((result) => {
      if (result.status === 1) {
        this.totalCount = Math.ceil(parseInt(result.data.total_count) / this.pagination.count);
        this.allProductList = result.data.listing;
      } else {
        this.toastr.error(result.message);
      }
    });
  }

  deleteProduct(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.deleteProduct({ productId: productId }).subscribe((result) => {
        const rs = result;
        if (rs.status === 1) {
          this.toastr.success('Success', rs.message);
          this.getAllProduct();
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }
}