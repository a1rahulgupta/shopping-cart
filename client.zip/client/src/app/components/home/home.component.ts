
import { Component, OnInit, Inject } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

// Components
import { ProductListComponent } from '../Product Management/product-list/product-list.component';
import { ProductAddComponent } from '../Product Management/product-add/product-add.component';

// Services
import { routerTransition } from '../../services/config/config.service';
import { CartListComponent } from '../Product Management/cart-list/cart-list.component';
import { CartProductListComponent } from '../Product Management/cart-product-list/cart-product-list.component';


@Component({
	selector: 'app-home',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css'],
	animations: [routerTransition()],
	host: { '[@routerTransition]': '' }
})


export class HomeComponent implements OnInit {
	active: string;
	constructor(private router: Router, private toastr: ToastrService) {
		// Detect route changes for active sidebar menu
		this.router.events.subscribe((val) => {
			this.routeChanged(val);
		});
	}

	ngOnInit() {
	}
	logOut() {
		this.toastr.success('Success', "Logged Out Successfully");
		localStorage.removeItem('token');
		this.router.navigate(['/login']);
	}

	// Detect route changes for active sidebar menu
	routeChanged(val) {
		this.active = val.url;
	}
}

export const homeChildRoutes: Routes = [
	{
		path: 'list',
		component: ProductListComponent
	},
	{
		path: 'list/cart-list',
		component: CartListComponent
	},
	{
		path: 'list/add',
		component: ProductAddComponent
	},
	{
		path: 'list/update/:id',
		component: ProductAddComponent
	},
	{
		path: 'list/cart-product-list',
		component: CartProductListComponent
	}
];
