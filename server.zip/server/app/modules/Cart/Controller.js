const i18n = require("i18n");
const _ = require('lodash');
const Controller = require('../Base/Controller');
const Model = require("../Base/Model");
const Cart = require('./Schema').Cart;
const RequestBody = require("../../services/RequestBody");
const CommonService = require("../../services/Common");
const { StatusCodes }  = require('http-status-codes');

class CartController extends Controller {
    constructor() {
        super();
    }


    async addProductToCart() {
        try {
            let fieldsArray = ['productId'];
            console.log(this.req.body)
            let data = await (new RequestBody()).processRequestBody(this.req.body, fieldsArray);
            const product = await Cart.findOne({productId:this.req.body.productId , isDeleted: false});
            if (!_.isEmpty(product)) {
                return this.res.status(203).send({ status: 0, message: i18n.__("DUPLICATE_PRODUCT") });
            } else {
                const cartData = await (new Model(Cart)).store(data);
                if (_.isEmpty(cartData)) {
                    return this.res.status(StatusCodes.BAD_REQUEST).send({ status: 0, message:i18n.__('PRODUCT_NOT_SAVED_TO_CART.') })
                }
                return this.res.status(StatusCodes.OK).send({ status: 1, message: i18n.__('PRODUCT_SAVED_TO_CART'), cartData });
             }
        } catch (error) {
            console.log("error- ", error);
            return this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }

    async cartList() {
        try {
            this.req.body['model'] = Cart;
            let data = { bodyData: this.req.body }
            let result = await new CommonService().listingCart(data);
            return this.res.send(result);
        } catch (error) {
            console.log("error- ", error);
            this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }

  
    async deleteProductInCart() {
        try {
            let msg = i18n.__("PRODUCT_NOT_DELETED");
            const updatedProduct = await Cart.update({ productId: this.req.body.productId , isDeleted: false }, { $set: { isDeleted: true } });
            if (updatedProduct) {
                msg = updatedProduct.nModified ? updatedProduct.nModified +  i18n.__("PRODUCT_DELETED") : updatedProduct.n == 0 ? i18n.__("PRODUCT_NOT_FOUND") : msg;
            }
            return this.res.status(StatusCodes.OK).send({ status: 1, message: msg });
        } catch (error) {
            console.log("error- ", error);
            this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }
   
  

}
module.exports = CartController;