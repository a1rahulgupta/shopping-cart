module.exports = (app, express) => {

    const router = express.Router();

    const CartController = require('./Controller');
    const config = require('../../../configs/configs');
    const Validators = require("./Validator");

    router.post('/addProductToCart', Validators.validate, (req, res, next) => {
        const cartObj = (new CartController()).boot(req, res, next);
        return cartObj.addProductToCart();
    });

    router.post('/deleteProductInCart', Validators.validate, (req, res, next) => {
        const cartObj = (new CartController()).boot(req, res, next);
        return cartObj.deleteProductInCart();
    });

    router.post('/cartList',  Validators.listingValidator(), Validators.validate, (req, res, next) => {
        const cartObj = (new CartController()).boot(req, res, next);
        return cartObj.cartList();
    });

    app.use(config.baseApiUrl, router);
}