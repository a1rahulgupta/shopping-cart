const mongoose = require('mongoose');
const schema = mongoose.Schema;

const cartSchema = new mongoose.Schema({
    productId: { type: schema.Types.ObjectId, ref: 'Products' },
    isDeleted: { type: Boolean, default: false },
}, {
    timestamps: true
});

const Cart = mongoose.model('Carts', cartSchema);
module.exports = {
    Cart
}