const i18n = require("i18n");
const _ = require('lodash');
const ObjectId = require('mongodb').ObjectID;
const Controller = require('../Base/Controller');
const Model = require("../Base/Model");
const Product = require('./Schema').Product;
const RequestBody = require("../../services/RequestBody");
const CommonService = require("../../services/Common");
const { StatusCodes }  = require('http-status-codes');
const formidable = require('formidable');
const fs = require('fs');

class ProductController extends Controller {
    constructor() {
        super();
    }


    async addUpdateProduct() {
        try {
            let fieldsArray = ['itemName', 'price','image'];
            let data = await (new RequestBody()).processRequestBody(this.req.body, fieldsArray);
            if (this.req.body.id) {
                const productData = await Product.findByIdAndUpdate(this.req.body.id, data, { new: true });
                if (_.isEmpty(productData)) {
                    return this.res.status(StatusCodes.NOT_MODIFIED).send({ status: 0, message: i18n.__('PRODUCT__NOT_UPDATED') })
                }
                return this.res.status(StatusCodes.OK).send({ status: 1, message: i18n.__('PRODUCT_UPDATED'), productData })
            } else {
                let filter = { "itemName": this.req.body.itemName.toLowerCase(),"isDeleted": false }
            const product = await Product.findOne(filter);
            if (!_.isEmpty(product) && (product.itemName)) {
                return this.res.status(203).send({ status: 0, message: i18n.__("DUPLICATE_PRODUCT") });
            } else {
                const productData = await (new Model(Product)).store(data);
                if (_.isEmpty(productData)) {
                    return this.res.status(StatusCodes.BAD_REQUEST).send({ status: 0, message:i18n.__('PRODUCT_NOT_SAVED.') })
                }
                return this.res.status(StatusCodes.OK).send({ status: 1, message: i18n.__('PRODUCT_SAVED'), productData });
            }
        }

        } catch (error) {
            console.log("error- ", error);
            return this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }



    async productList() {
        try {
            this.req.body['model'] = Product;
            let data = { bodyData: this.req.body }
            if (this.req.body.searchText) {
                data.fieldsArray = ['itemName']
                data.searchText = this.req.body.searchText;
            }
            let result = await new CommonService().listingProduct(data);
            return this.res.send(result);
        } catch (error) {
            console.log("error- ", error);
            this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }



    async productDetail() {
        try {
            const productData = await Product.findOne({ _id: ObjectId(this.req.params.productId), isDeleted: false }, { __v: 0 });
            return this.res.send(_.isEmpty(productData) ? { status: 0, message: i18n.__('PRODUCT_NOT_FOUND') } : { status: 1, data: productData });
        } catch (error) {
            console.log("error- ", error);
            this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }


    async deleteProduct() {
        try {
            let msg = i18n.__("PRODUCT_NOT_DELETED");
            const updatedProduct = await Product.update({ _id: this.req.body.productId, isDeleted: false }, { $set: { isDeleted: true } });
            if (updatedProduct) {
                msg = updatedProduct.nModified ? updatedProduct.nModified +  i18n.__("PRODUCT_DELETED") : updatedProduct.n == 0 ? i18n.__("PRODUCT_NOT_FOUND") : msg;
            }
            return this.res.status(StatusCodes.OK).send({ status: 1, message: msg });
        } catch (error) {
            console.log("error- ", error);
            this.res.status(StatusCodes.INTERNAL_SERVER_ERROR).send({ status: 0, message: error });
        }
    }

    
    async  fileUpload() {
        let _this = this;
        try {
            let form = new formidable.IncomingForm();
        form.parse(this.req, (err, fields, files) => {
            var oldpath = files.file.path;
            var newpath = './public/' + files.file.name;
            console.log(newpath)
            fs.rename(oldpath, newpath, (err) => {
                console.log(err)
                if (err) return this.res.send({ message: err, status: 0 });
                else return this.res.send({ status: 1, fileName: files.file.name, filePath: 'http://localhost:5005/public/' + files.file.name });
            });
        });
        } catch (error) { console.log("error- ", error); _this.res.send({ status: 0, message: error }); }
    }




   
  

}
module.exports = ProductController;