module.exports = (app, express) => {

    const router = express.Router();
    const ProductController = require('./Controller');
    const config = require('../../../configs/configs');
    const Validators = require("./Validator");

    router.post('/addUpdateProduct', Validators.productValidator(), Validators.validate, (req, res, next) => {
        const productObj = (new ProductController()).boot(req, res, next);
        return productObj.addUpdateProduct();
    });

    router.get('/getProductDetails/:productId', Validators.detailValidator(), Validators.validate, (req, res, next) => {
        const productObj = (new ProductController()).boot(req, res, next);
        return productObj.productDetail();
    });

    router.post('/deleteProduct', Validators.validate, (req, res, next) => {
        const productObj = (new ProductController()).boot(req, res, next);
        return productObj.deleteProduct();
    });

    router.post('/productList', Validators.listingValidator(), Validators.validate, (req, res, next) => {
        const productObj = (new ProductController()).boot(req, res, next);
        return productObj.productList();
    });

    router.post('/fileUpload', (req, res, next) => {
        const productObj = (new ProductController()).boot(req, res, next);
        return productObj.fileUpload();
    });

    app.use(config.baseApiUrl, router);
}