const mongoose = require('mongoose');
// const schema = mongoose.Schema;

const productSchema = new mongoose.Schema({
    itemName: { type: String },
    price: { type: Number },
    image:{type:String},
    quantity:{type: Number , default: 1},
    isDeleted: { type: Boolean, default: false },
}, {
    timestamps: true
});

const Product = mongoose.model('Products', productSchema);
module.exports = {
    Product
}