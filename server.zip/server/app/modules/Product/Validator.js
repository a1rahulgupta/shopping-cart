
const _ = require("lodash");
const i18n = require("i18n");
const { validationResult } = require('express-validator');
const { body, check, query, header, param } = require('express-validator');

class Validators {
    static productValidator() {
        try {
            return [
                check('itemName').exists().withMessage(i18n.__("%s REQUIRED", 'ItemName')),
                check('price').exists().withMessage(i18n.__("%s REQUIRED", 'Price')),
                check('image').exists().withMessage(i18n.__("%s REQUIRED", 'Image'))
            ];
        } catch (error) {
            return error;
        }
    }

    static listingValidator() {
        try {
            return [
                check('page').isNumeric().withMessage(i18n.__("%s REQUIRED", 'Page')),
                check('pagesize').isNumeric().withMessage(i18n.__("%s REQUIRED", 'Pagesize'))
            ];
        } catch (error) {
            return error;
        }
    }


    static detailValidator() {
        try {
            return [
                param('productId').exists().withMessage(i18n.__("%s REQUIRED", 'Product Id')),
                param('productId').not().equals('undefined').withMessage(i18n.__("%s REQUIRED", 'Valid ' + 'Product Id')),
                param('productId').not().equals('null').withMessage(i18n.__("%s REQUIRED", 'Valid ' + 'Product Id')),
                param('productId').isAlphanumeric().withMessage(i18n.__("%s REQUIRED", 'Valid ' + 'Product Id')),
                param('productId').not().isEmpty().withMessage(i18n.__("%s REQUIRED", 'Valid ' + 'Product Id'))
            ];
        } catch (error) {
            return error;
        }
    }
  

    static validate(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(422).json({ status: 0, message: errors.array() });
            }
            next();
        } catch (error) {
            return res.send({ status: 0, message: error });
        }
    }
}

module.exports = Validators;