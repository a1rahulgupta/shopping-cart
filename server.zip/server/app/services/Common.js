
const _ = require("lodash");
const bcrypt = require('bcrypt');
const i18n = require("i18n");
const Config = require('../../configs/configs');




class Common {

    listingProduct(data) {
        return new Promise(async (resolve, reject) => {
            try {
                let bodyData = data.bodyData;
                let model = data.bodyData.model;
                let searchText = data.searchText ? data.searchText : '';
                if (bodyData.page && bodyData.pagesize) {
                    let skip = (bodyData.page - 1) * (bodyData.pagesize);
                    let sort = bodyData.sort ? bodyData.sort : { createdAt: -1 };
                    let search = (searchText != '') ? await this.searchData({ searchText, fieldsArray }) : {};
                    let listing; let finalQuery;
                    finalQuery = {...search, isDeleted:false };
                    listing =  await model.find(finalQuery).sort(sort).skip(skip).limit(bodyData.pagesize)
                    const total = await model.find(finalQuery).countDocuments()
                        return resolve({ status: 1, data: { listing }, page: parseInt(bodyData.page), perPage: parseInt(bodyData.pagesize), total: total });
                    
                } else {
                    return resolve({ status: 0, message: "Page and pagesize required." })
                }
            } catch (error) {
                return reject(error)
            }
        });
    }
    listingCart(data) {
        return new Promise(async (resolve, reject) => {
            try {
                let bodyData = data.bodyData;
                let model = data.bodyData.model;
                let searchText = data.searchText ? data.searchText : '';
                if (bodyData.page && bodyData.pagesize) {
                    let skip = (bodyData.page - 1) * (bodyData.pagesize);
                    let sort = bodyData.sort ? bodyData.sort : { createdAt: -1 };
                    let search = (searchText != '') ? await this.searchData({ searchText, fieldsArray }) : {};
                    let listing; let finalQuery;
                    finalQuery = {...search, isDeleted:false };
                    listing =  await model.find(finalQuery).sort(sort).skip(skip).limit(bodyData.pagesize).populate('productId')
                    const total = await model.find(finalQuery).countDocuments()
                        return resolve({ status: 1, data: { listing }, page: parseInt(bodyData.page), perPage: parseInt(bodyData.pagesize), total: total });
                    
                } else {
                    return resolve({ status: 0, message: "Page and pagesize required." })
                }
            } catch (error) {
                return reject(error)
            }
        });
    }


    searchData(data) {
        return new Promise(async (resolve, reject) => {
            try {
                let searchText = data.searchText;
                let fieldsArray = data.fieldsArray;
                let orArray = [];
                await fieldsArray.map(data => {
                    orArray.push({ [data]: { $regex: '.*' + searchText + '.*', $options: 'i' } });
                })
                return resolve({ $and: [{ $or: orArray }] })
            } catch (error) {
                return reject(error);
            }
        })
    }

}

module.exports = Common;